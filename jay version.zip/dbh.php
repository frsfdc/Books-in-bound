<?php
$conn= mysqli_connect("localhost","root","","booksinbound");
if(!$conn){
	die("Connection failed: ".mysqli_connect_error());
}
?>

