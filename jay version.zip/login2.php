<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="css/logstyle.css">
</head>
<body>
  <div class="container">
  <img src="images/user.png">
	<form method="post" action="signup.php";>
		<div class="form-input">
			<input type="text" name="username" placeholder="Enter username">
		</div>	
		<div class="form-input">
			<input type="password" name="password" placeholder="Enter password">
		</div>
	  <input type="submit" name="Submit" value="Login" class="btn-login"><br>	
      <a href="#">Forgot your password?</a><br>
      <a href="register.html">Register now</a> 	  
	</form>
  </div>
</body>

</html>  

