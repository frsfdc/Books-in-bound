        <footer>
            <div id="footer">
                <div id="support">
                    <p>Support</p>
                    <ul>
                        <a href="../site/contact.php"><li>Contact Us</li></a>
						<a href="#" style="visibility:none;"><li>faq</li></a>
                        <a href="../site/help.php"><li>Help</li></a>
                    </ul>
                </div>

                <div id="quick_links">
                    <p>Quick Links</p>
                    <ul>
                        <a href="#browse"><li>Search</li></a>
                        <a href="../site/about.php"><li>About Us</li></a>
                    </ul>
                </div>
            </div>
            
            <div id="link_footer">
                <ul>
                    <a href="../site/index.php"><li>&#169; Booksinbound.com</li></a>
                    <a href="../site/privacy.php"><li>Privacy policy</li></a>
                    <a href="../site/terms.php"><li>Terms and conditions</li></a>
                </ul>
            </div>
        </footer>

        <script src="../assets/js/script.js"></script>
    </body>
</html>