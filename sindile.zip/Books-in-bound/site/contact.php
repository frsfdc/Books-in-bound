<?php  require_once( "../includes/layouts/header.php" ); ?>

        <div class="main_content contact">
			<h1>contant Us</h1>
            <p>At booksinbound we are always help to help so if you would like to get in touch with us regarding anything to do with our services please 
                fill the form below:</p>
            <form>
                <fieldset>
                    <legend>Contact Us</legend>
                    <p><label>Name:     <input type="text" name="first_name" required></label> *</p>
                    <p><label>Email:    <input type="email" name="email_adress" required></label> *</p>
					<p><label>Subject:  <input type="text" name="subject" ></label></p>
                    <p> <textarea rows="10" cols="70">Enter Comments...</textarea></p>
					<p style="float: right;">* fields are required</p>
                    <p>                 <input type="submit" name="submit" value="submit"></p>
                </fieldset>
            </form>
        </div> <!-- End of about us div -->

<?php  require_once( "../includes/layouts/footer.php" ); ?>