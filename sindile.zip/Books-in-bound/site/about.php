<?php  require_once( "../includes/layouts/header.php" ); ?>

        <div class="main_content about">
            <h1>About Us</h1>
            <p>Books in bound is a website that gives students the opportunity to swap their unwanted books with
                other students in their current city. Lorem ipsum dolor sit amet, consectetur adipisicing elit. 
                Quisquam beatae deserunt fugit doloremque odio, similique alias veritatis tempora, mollitia ducimus 
                incidunt rerum eius omnis minima voluptate! Enim accusantium voluptas, quis.</p>
            <p>Books in bound is a website that gives students the opportunity to swap their unwanted books with
                other students in their current city. Lorem ipsum dolor sit amet, consectetur adipisicing elit. 
                Quisquam beatae deserunt fugit doloremque odio, similique alias veritatis tempora, mollitia ducimus 
                incidunt rerum eius omnis minima voluptate! Enim accusantium voluptas, quis.</p>
            <p>Books in bound is a website that gives students the opportunity to swap their unwanted books with
                other students in their current city. Lorem ipsum dolor sit amet, consectetur adipisicing elit. 
                Quisquam beatae deserunt fugit doloremque odio, similique alias veritatis tempora, mollitia ducimus 
                incidunt rerum eius omnis minima voluptate! Enim accusantium voluptas, quis.</p>
            <p>Books in bound is a website that gives students the opportunity to swap their unwanted books with
                other students in their current city. Lorem ipsum dolor sit amet, consectetur adipisicing elit. 
                Quisquam beatae deserunt fugit doloremque odio, similique alias veritatis tempora, mollitia ducimus 
                incidunt rerum eius omnis minima voluptate! Enim accusantium voluptas, quis.</p>
        </div> <!-- End of about us div -->

<?php  require_once( "../includes/layouts/footer.php" ); ?>