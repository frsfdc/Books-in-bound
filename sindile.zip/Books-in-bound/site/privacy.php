<?php require_once( "../includes/layouts/header.php" ); ?>

        <div class="main_content">
		</div>
		
<?php require_once("../includes/layouts/footer.php") ?>