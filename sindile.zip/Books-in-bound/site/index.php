<?php  require_once( "../includes/layouts/header.php" ); ?>

        <div id="content">
            <h1>Welcome to <br>Books in Bound</h1>
        </div> <!-- End of content div -->

<?php require_once( "../includes/layouts/footer.php" ); ?>