<?php require_once("../includes/session.php"); ?>
<?php require_once( "../includes/db_connection.php" ) ?>
<?php require_once( "../includes/functions.php" ); ?>
<?php require_once( "../includes/validation.php" ); ?>

<?php
    // Get default form variables:
    $username   = "";
    $first_name = "";
    $last_name  = "";
    $password   = "";
    $city       = "";
    $email      = "";
    $university = "";
    $gender     = "";

    // Check if the form is coming from a post request:
    if( $_SERVER['REQUEST_METHOD'] === 'POST' )
    {
        $cancel = isset($_POST["cancel"]) ? $_POST["cancel"] : "";
        if( $cancel == "cancel" ) redirect( "index.php" );

        // select the required fields:
        $required_fields = array( "username", "first_name", "last_name", "password", "city", "email" );
        validate_presences( $required_fields );

        if( !empty($errors) )
        {
            $_SESSION["errors"] = $errors;
        }
        // Get all the values
        $username   = escape( $_POST["username"]   );
        $first_name = escape( $_POST["first_name"] );
        $last_name  = escape( $_POST["last_name"]  );
        $password   = escape( $_POST["password"]   );
        $city       = escape( $_POST["city"]       );
        $email      = escape( $_POST["email"]      );
        $university = escape( $_POST["university"] );
        $gender     = escape( $_POST["gender"]     );

        $pass = encrypt_pass( $password );

        // Store in the database:
        $query = "INSERT INTO users(USERNAME, FIRSTNAME, LASTNAME, PASS, TOWN, GENDER, EMAIL, UNI, BOOKSOWNED) ";
        $query .= "VALUES('{$username}', '$first_name', '$last_name', '{$pass}', '{$city}', '{$gender}', '{$email}', '{$university}', null )";

        $result = mysqli_query( $connection, $query );

        if( $result && empty($errors) )
        {
            redirect( "login.php" );
        }
    }
?>

<!DOCTYPE html>

<html lang="en-gb">
    <head>
        <meta charset="utf-8">
        <meta name="description" content="A books trading website for students">
        <meta name="viewport" content="width=device-with, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="shortcut icon" href="assets/images/marcus_play_book.ico">
        <!--link rel="stylesheet" href="assets/css/reset.css" type="text/css"-->
        <link rel="stylesheet" href="assets/css/register.css" type="text/css">

        <style>
            .error {
                color: red;
                text-align: center;
            }
        </style>

        <title>Signup - Books in bound</title>
    </head>

    <body>
        <?php #echo session_message()  ?>
        <?php $errors = error(); ?>
        <?php echo form_errors( $errors ); ?>
        <div id="container">
        <form action="register.php" method="post" >
            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" value="" id="first_name" value="<?php echo $first_name ?>"><br>

            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" value="" id="last_name" value="<?php $last_name ?>"><br>

            <label for="a"><b>Username:</b></label>
            <input id="a" type="text" placeholder="Enter Username" name="username" value="<?php echo $username ?>"><br />

            <label><b>Email:</b></label>
            <input type="text" placeholder="Enter Email" name="email" value="<?php echo $email ?>" ><br />

            <label><b>Password:</b></label>
            <input type="password" placeholder="Enter Password" name="password" ><br />

            <label><b>Repeat Password:</b></label>
            <input type="password" placeholder="Repeat Password" name="psw-repeat"><br />

            <label><b>Gender:</b></label><br>
            <input type="radio" name="gender" value="male" checked> Male
            <input type="radio" name="gender" value="female"> Female<br />

            <label><b>City:</b></label>
            <input type="text" placeholder="City" name="city"><br />

            <label><b>University:</b></label>
            <input type="text" placeholder="Enter University" name="university" value=""><br />

            <p>By creating an account you agree to our <a href="privacy.html">Terms &#38; Privacy.</a></p>

            <div class="clearfix">
            <button name="cancel" value="cancel" class="cancelbtn">Cancel</button>
            <button name="submit" class="signupbtn">Sign Up</button>
            </div>
        </form>
        </div>
    </body>
</html>
