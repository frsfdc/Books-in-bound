<!DOCTYPE html>
<html lang="en-gb">
	<head>
		<meta charset="utf-8">
		<meta name="description" content="A books trading website for students">
		<meta name="viewport" content="width=device-with, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="shortcut icon" href="../assets/images/marcus_play_book.ico">
		<link rel="stylesheet" href="../assets/css/reset.css" type="text/css">
		<link rel="stylesheet" type="text/css" href="../assets/css/logstyle.css">

		<title>Login - Books in bound</title>
	</head>

	<body>
		<div class="container">
		<img src="../assets/images/user.png">
		<form>
			<div class="form-input">
				<input type="text" name="username" placeholder="Enter username">
			</div>	
			<div class="form-input">
				<input type="password" name="password" placeholder="Enter password">
			</div>
			<input type="submit" name="Submit" value="Login" class="btn-login"><br>	
				<a href="#">Forgot your password?</a><br>
				<a href="register.html">Sign up</a> 	  
		</form>
		</div>
	</body>
</html>  
